# 01 Planejamento

## 1.1 Visão

## 1.2 Camadas

## 1.3 Tríade: tempo, custo e escopo

## 1.4 Processo de Desenvolvimento

Planejamento
Análise
Design
Implementação
Verificação
Validação
Implantação
Evolução

# 02 Análise dos Requisitos

# 03 Desgin (projetos)

# 04 Implementação (codificação)

# 05 Testes (verificação e validação)

# 06 Gerência de configuração

# 07 Gerência da qualidade

## Conhecimentos:

http://www.dsc.ufcg.edu.br/~jacques/cursos/apoo/html/intro/intro2.htm
