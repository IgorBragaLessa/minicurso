# Gerência de configuração

# cgatGpt: crie um documento em makdown para a gerencia de configuração para o projeto conta bancária com login e registro do usuario
