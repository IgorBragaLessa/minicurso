# Testes do sistema - Testes das funcionlidades

# Testes das Funcionalidades

## Funcionalidade: Parte 1 - feature: Registro do Usuário

### Teste 1.1: Página de Registro

-   **Status:** [x] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**

### Teste: Validação de E-mail e Senha Não Vazios

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**

### Teste: Verificação de E-mail Já em Uso

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**

### Teste: Envio de E-mail de Verificação

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**

### Teste: Confirmação de Registro Bem-Sucedido

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**

### Teste: Campos Obrigatórios em Branco

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**

### Teste: Registro com E-mail Já em Uso

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**

### Teste: Mensagem de Erro para Campos Obrigatórios

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:**
