# Testes

## teste do sistema

# cgatGpt: crie os Testes de sistemas, incluindo os cenários de suceeso e erros em markdown .md com este formato:

Funcionlidade: Parte 1 - feature: Registro do usuário
status
Descrição do erro ou ajuste:
Observação/Sugestão:

# cgatGpt: crie os Testes de usabilidade para o usuário em markdown .md com este formato:

Funcionlidade: Parte 1 - feature: Registro do usuário
status
Descrição do erro ou ajuste:
Observação/Sugestão:
