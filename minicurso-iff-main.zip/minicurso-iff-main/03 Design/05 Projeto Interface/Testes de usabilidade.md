# Testes de usabilidade do protótipo

## Funcionalidade: Parte 1 - Registro do Usuário

### Teste 1.1: Página de Registro

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:** Avaliar a clareza e a facilidade de navegação na página de registro. Verificar se os campos são intuitivos e a disposição é lógica para o usuário.

## Funcionalidade: Parte 2 - Login no sistema

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:** Avaliar a clareza e a facilidade de navegação na página de login. Verificar se os campos são intuitivos e a disposição é lógica para o usuário.

## Funcionalidade: Parte 3 - Home - index

-   **Status:** [ ] Passou [ ] Falhou
-   **Descrição do erro ou ajuste:**
-   **Observação/Sugestão:** Avaliar a clareza e a facilidade de navegação na página home. Verificar se os campos são intuitivos e a disposição é lógica para o usuário.
