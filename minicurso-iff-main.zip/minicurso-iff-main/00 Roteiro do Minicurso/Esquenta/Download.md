# Dentro da pasta 00Minicurso>projeto-final:

Dentro da basta baixar:

# o front:

https://github.com/leonardorsolar/front-form.git
No vscode: Instale a extensão live server no vscode

# o back typescript:

https://github.com/leonardorsolar/server-typescript-form-iff-mvc.git

# o back java:

https://github.com/leonardorsolar/server-java-form-mvc.git

```lua


00Minicurso
│
├── minicurso-iff
│
├── projeto-final
│   │
│   ├── front-form
│   │   ├── ...
│   │   └── ...
│   ├── server-typescript-form-iff-mvc
│   │   ├── ...
│   │   └── ...
│   └── server-java-form-mvc
│       ├── ...
│       └── ...
│
└──
```
