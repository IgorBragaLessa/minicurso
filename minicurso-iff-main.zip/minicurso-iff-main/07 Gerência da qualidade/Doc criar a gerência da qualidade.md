# Gerência da qualidade

# cgatGpt: crie um documento em makdown para a gerencia da qualidade para o projeto conta bancária com login e registro do usuario
