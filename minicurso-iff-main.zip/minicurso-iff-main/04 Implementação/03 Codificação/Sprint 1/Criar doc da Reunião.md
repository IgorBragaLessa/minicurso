# Documento de Reunião - Sprint 1

# cgatGpt: crie um documento de reunião da revisão da sprint e reuniao da retrospectiva e para a sprint 1 no formato markdown:
