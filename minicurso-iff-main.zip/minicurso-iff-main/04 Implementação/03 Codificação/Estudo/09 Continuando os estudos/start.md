# Programação orientado a objetos

Interfaces
Métodos estáticos
Encapsulamento e polimorfismo

# Desenvolvimento orientado a testes

Teste de unidade
Teste de integração

# Clean Code

# Princípios de Design

Inversão e injeção de dependência (SOLID)

# Análise orientado a objetos

# Padrões de design

O padrão de fábrica
O padrão do construtor
